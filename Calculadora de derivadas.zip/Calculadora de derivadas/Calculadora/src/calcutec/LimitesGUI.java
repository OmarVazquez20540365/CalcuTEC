package calcutec;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class LimitesGUI extends JFrame {
    private JTextField expressionField;
    private JTextField xValueField;
    private JLabel resultLabel;
    private JTextArea procedureTextArea;
    private JButton calculateButton;
    private JButton powerButton;

    public LimitesGUI() {
        setTitle("Cálculo de Límites");
        setSize(500, 300); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel expressionLabel = new JLabel("Expresión:");
        expressionLabel.setBounds(20, 20, 80, 25);
        add(expressionLabel);

        expressionField = new JTextField();
        expressionField.setBounds(120, 20, 300, 25);
        add(expressionField);

        JLabel xValueLabel = new JLabel("Valor de x:");
        xValueLabel.setBounds(20, 50, 80, 25);
        add(xValueLabel);

        xValueField = new JTextField();
        xValueField.setBounds(120, 50, 100, 25);
        add(xValueField);

        calculateButton = new JButton("Calcular Límite");
        calculateButton.setBounds(20, 80, 150, 30);
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateLimit();
            }
        });
        add(calculateButton);

        powerButton = new JButton("^");
        powerButton.setBounds(200, 80, 50, 30);
        powerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insertPowerSymbol();
            }
        });
        add(powerButton);

        resultLabel = new JLabel();
        resultLabel.setBounds(20, 120, 450, 30); 
        add(resultLabel);

        procedureTextArea = new JTextArea();
        procedureTextArea.setBounds(20, 150, 450, 100); 
        procedureTextArea.setEditable(false); 
        JScrollPane scrollPane = new JScrollPane(procedureTextArea); 
        scrollPane.setBounds(20, 150, 450, 100);
        add(scrollPane);
    }

    private void calculateLimit() {
        String expression = expressionField.getText();
        double x;

        try {
            x = Double.parseDouble(xValueField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, introduce un valor válido para x.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ExpressionBuilder exp = new ExpressionBuilder(expression);
        exp.variable("x");
        Limites lim = new Limites(x, exp.build(), expressionField.getText());


        try {
            double result = lim.evalLimit();
            resultLabel.setText("Resultado: " + result);
            procedureTextArea.setText("Procedimiento:\n" + lim.getProcedure());
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, "El límite no existe.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertPowerSymbol() {
        String currentExpression = expressionField.getText();
        expressionField.setText(currentExpression + "^");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                LimitesGUI gui = new LimitesGUI();
                gui.setVisible(true);
            }
        });
    }
}

class Limites {
    private final double x;
    private final Expression op;
    private final String originalExpression; // Guarda la expresión original introducida
    private final int PRECISION = 7;
    private DecimalFormat decimalFormat = new DecimalFormat("#.####");
    private List<String> procedureSteps = new ArrayList<>(); 

    public Limites(double x, Expression op, String originalExpression) {
        if (op == null) throw new IllegalArgumentException();
        this.x = x;
        this.op = op;
        this.originalExpression = originalExpression; // Guarda la expresión original
    }

    public double evalLimit() {
    Double eval = null;
    double prevEval = 0; // Guarda el resultado de la evaluación en el paso anterior

    for (int i = 1; i != PRECISION; i++) {
        try {
            eval = op.setVariable("x", x).evaluate();

            // Construye la cadena de operación realizada en este paso
            String operation = "Paso " + i + ": " + originalExpression + " = " + eval;

            // Si no es el primer paso, agrega la operación realizada
            if (i > 1) {
                operation += " (Operación: " + originalExpression + " - " + prevEval + " = " + eval + ")";
            }

            procedureSteps.add(operation);

            // Actualiza el resultado anterior con el resultado actual
            prevEval = eval;
        } catch (Exception e) {
            break;
        }
    }

    if (eval == null) {
        throw new IllegalStateException("El límite no existe");
    }

    return eval;
}

    public String getProcedure() {
        StringBuilder procedure = new StringBuilder();
        for (String step : procedureSteps) {
            procedure.append(step).append("\n");
        }
        return procedure.toString();
    }
}
