package calcutec;

import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;
import org.nfunk.jep.ParseException;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Omar_Vazquez
 */
public class Derivadas {

    private String funcion = "";
    private String derivadaFormula = "";
    private Map<String, String> operaciones = new HashMap<>();

    DJep djep;
    Node nodoFuncion;
    Node nodoDerivada;

    public Derivadas() {
        //...
    }

    public void setFuncionADerivar(String funcion) {
        this.funcion = funcion;
    }

    public String getFuncionDerivada() {
        return this.funcion;
    }

    public String getDerivadaFormula() {
        return derivadaFormula;
    }

    public Map<String, String> getOperaciones() {
        return operaciones;
    }

    public void derivar() {

        try {

            this.djep = new DJep();
            // agrega funciones estandares cos(x), sin(x)
            this.djep.addStandardFunctions();

            // agrega constantes estandares, pi, e, etc
            this.djep.addStandardConstants();

            // por si existe algun numero complejo
            this.djep.addComplex();

            // permite variables no declarables
            this.djep.setAllowUndeclared(true);

            // permite asignaciones
            this.djep.setAllowAssignment(true);

            // regla de multiplicacion o para sustraccion y sumas
            this.djep.setImplicitMul(true);

            // regla de multiplicacion o para sustraccion y sumas
            this.djep.addStandardDiffRules();

            // coloca el nodo con una funcion preestablecida
            this.nodoFuncion = this.djep.parse(this.funcion);

            // Define the derivadaFormula based on the function
            if (this.funcion.contains("+")) {
                derivadaFormula = "f(x) = g(x) + h(x), f'(x) = g'(x) + h'(x)";
            } else if (this.funcion.contains("-")) {
                derivadaFormula = "f(x) = g(x) - h(x), f'(x) = g'(x) - h'(x)";
            } else if (this.funcion.contains("*")) {
                derivadaFormula = "f(x) = g(x) * h(x), f'(x) = g'(x) * h(x) + g(x) * h'(x)";
            } else if (this.funcion.contains("/")) {
                derivadaFormula = "f(x) = g(x) / h(x), f'(x) = (h(x) * g'(x) - g(x) * h'(x)) / h(x)^2";
            } else {
                derivadaFormula = "f(x) = c * g(x), f'(x) = c * g'(x)";
            }

            // derivar la funcion para x
            Node diff = this.djep.differentiate(nodoFuncion, "x");

            // Simplificamos la funcion derivada
            this.nodoDerivada = this.djep.simplify(diff);

            // esto convierte el valor que se generó de la derivada en un string
            this.funcion = this.djep.toString(this.nodoDerivada);

            // Add operations to the map
            addOperation("Function", this.funcion);
addOperation("Derivative Formula", this.derivadaFormula);
            addOperation("Derived Function", this.funcion);

        } catch (ParseException e) {
            this.funcion = "NaN";
            System.out.println("Error: " + e.getErrorInfo());
        }

    }

    private void addOperation(String key, String value) {
        operaciones.put(key, value);
    }

}

